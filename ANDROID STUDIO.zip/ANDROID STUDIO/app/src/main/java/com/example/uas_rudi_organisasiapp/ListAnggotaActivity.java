package com.example.uas_rudi_organisasiapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.uas_rudi_organisasiapp.R;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListAnggotaActivity extends AppCompatActivity {
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_anggota); // Pastikan file layout benar

        listView = findViewById(R.id.listAnggota); // Pastikan ID benar di XML

        // Ambil status dari Intent
        String status = getIntent().getStringExtra("status");

        // Inisialisasi Retrofit
        com.example.aplikasi.ApiInterface apiInterface;
        apiInterface = com.example.aplikasi.RetrofitClient.getRetrofitInstance().create(com.example.aplikasi.ApiInterface.class);

        // Panggil API
        apiInterface.getAnggota(status).enqueue(new Callback<List<String>>() {
            @Override
            public void onResponse(Call<List<String>> call, Response<List<String>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // Respons berhasil, tampilkan data di ListView
                    List<String> data = response.body();
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(ListAnggotaActivity.this, android.R.layout.simple_list_item_1, data);
                    listView.setAdapter(adapter);
                } else {
                    // Respons gagal
                    Toast.makeText(ListAnggotaActivity.this, "Gagal mengambil data", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<String>> call, Throwable t) {
                // Gagal koneksi ke API
                Toast.makeText(ListAnggotaActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
