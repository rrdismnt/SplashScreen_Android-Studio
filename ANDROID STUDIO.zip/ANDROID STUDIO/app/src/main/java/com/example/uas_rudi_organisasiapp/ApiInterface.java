package com.example.aplikasi;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("fetch_data.php") // Sesuaikan nama endpoint API PHP
    Call<List<String>> getAnggota(@Query("status") String status);
}
