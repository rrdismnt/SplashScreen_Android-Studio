package com.example.uas_rudi_organisasiapp; // Sesuaikan dengan package aplikasi Anda

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.example.uas_rudi_organisasiapp.R;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Delay 3 detik, lalu pindah ke MainActivity
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashActivity.this, com.example.uas_rudi_organisasiapp.MainActivity.class);
                startActivity(intent);
                finish(); // Menutup SplashActivity agar tidak bisa kembali ke sini
            }
        }, 3000); // 3000 ms = 3 detik
    }
}
